# bellumMod
Changes proposed by Lion.Kanzen, Valihrant and the rest of the 0AD forum. 
Major balancing changes:
1. Skirmishers bonus vs elephants.
2. Cav spear bonus vs siege and archers.
3.Lancer (Cataphracts ,  Ptolemy Royal guard and Macedonian Hetero I) x 1.2 vs infantry sword and infantry archers 1.5 vs cavalry ranged and calvary spear.
4.Archers bonus X1.2 vs infantry spear.
5.Cavalry sword bonus vs support units and siege.
6.Bolt shooter bonus vs infantry 
7.Bolt shooters, Lithobolos have smaller minimum range and are less vulnerable to projectiles. 
